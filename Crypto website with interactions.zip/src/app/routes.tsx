import { createBrowserRouter } from "react-router";
import { Root } from "./components/Root";
import { Home } from "./components/Home";
import { Fixtures } from "./components/Fixtures";
import { News } from "./components/News";
import { Videos } from "./components/Videos";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: "fixtures", Component: Fixtures },
      { path: "news", Component: News },
      { path: "videos", Component: Videos },
    ],
  },
]);
