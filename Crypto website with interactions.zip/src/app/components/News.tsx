import { motion } from "motion/react";
import { Newspaper, Calendar, User, ArrowRight, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface NewsArticle {
  id: number;
  title: string;
  excerpt: string;
  author: string;
  date: string;
  category: string;
  image: string;
  featured?: boolean;
}

const newsArticles: NewsArticle[] = [
  {
    id: 1,
    title: "Bitcoin Reaches New All-Time High as Institutional Adoption Grows",
    excerpt:
      "Major financial institutions continue to embrace cryptocurrency, driving Bitcoin to unprecedented levels. Experts predict continued growth throughout 2026.",
    author: "Sarah Johnson",
    date: "May 30, 2026",
    category: "Market Analysis",
    image:
      "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcnlwdG8lMjBpbnZlc3RtZW50JTIwY2hhcnR8ZW58MXx8fHwxNzgwMjQxMzcyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    featured: true,
  },
  {
    id: 2,
    title: "Ethereum 3.0 Upgrade Promises Revolutionary Scalability",
    excerpt:
      "The latest Ethereum upgrade introduces groundbreaking technology that could process millions of transactions per second.",
    author: "Michael Chen",
    date: "May 29, 2026",
    category: "Technology",
    image:
      "https://images.unsplash.com/photo-1644088379091-d574269d422f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxibG9ja2NoYWluJTIwbmV0d29yayUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzgwMjQxMzcyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 3,
    title: "DeFi Platforms See Record Trading Volumes This Quarter",
    excerpt:
      "Decentralized finance continues to disrupt traditional banking with billions in daily trading volume across major platforms.",
    author: "Emily Rodriguez",
    date: "May 28, 2026",
    category: "DeFi",
    image:
      "https://images.unsplash.com/photo-1640161704729-cbe966a08476?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcnlwdG9jdXJyZW5jeSUyMGJsb2NrY2hhaW4lMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc4MDI0MTM3MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 4,
    title: "NFT Market Experiences Renaissance with New Gaming Applications",
    excerpt:
      "Gaming companies integrate NFTs in innovative ways, bringing new life to the digital collectibles market.",
    author: "David Park",
    date: "May 27, 2026",
    category: "NFT",
    image:
      "https://images.unsplash.com/photo-1623227413711-25ee4388dae3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcnlwdG9jdXJyZW5jeSUyMGdvbGQlMjBjb2lufGVufDF8fHx8MTc4MDI0MTM3Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 5,
    title: "Central Banks Explore Digital Currency Partnerships",
    excerpt:
      "Several countries announce collaborations on central bank digital currencies, potentially reshaping global finance.",
    author: "Lisa Anderson",
    date: "May 26, 2026",
    category: "Regulation",
    image:
      "https://images.unsplash.com/photo-1634704784915-aacf363b021f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiaXRjb2luJTIwdHJhZGluZyUyMGRpZ2l0YWx8ZW58MXx8fHwxNzgwMjQxMzcxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 6,
    title: "Crypto Staking Rewards Hit Record Highs",
    excerpt:
      "Proof-of-stake networks offer unprecedented returns as more users participate in network validation.",
    author: "James Wilson",
    date: "May 25, 2026",
    category: "Staking",
    image:
      "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcnlwdG8lMjBpbnZlc3RtZW50JTIwY2hhcnR8ZW58MXx8fHwxNzgwMjQxMzcyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
];

export function News() {
  const featuredArticle = newsArticles.find((article) => article.featured);
  const regularArticles = newsArticles.filter((article) => !article.featured);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <Newspaper className="size-16 text-purple-400 mx-auto mb-6" />
          <h1 className="text-5xl md:text-6xl text-white mb-4">
            Crypto News
          </h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Stay updated with the latest developments in the cryptocurrency world
          </p>
        </motion.div>

        {/* Featured Article */}
        {featuredArticle && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mb-12"
          >
            <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-sm overflow-hidden hover:border-purple-500/50 transition-all">
              <div className="grid md:grid-cols-2 gap-6">
                <motion.div
                  className="relative h-64 md:h-auto overflow-hidden"
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.3 }}
                >
                  <ImageWithFallback
                    src={featuredArticle.image}
                    alt={featuredArticle.title}
                    className="w-full h-full object-cover"
                  />
                  <Badge className="absolute top-4 left-4 bg-purple-600 hover:bg-purple-700">
                    Featured
                  </Badge>
                </motion.div>
                <div className="p-6 flex flex-col justify-center">
                  <Badge className="w-fit mb-4 bg-blue-600 hover:bg-blue-700">
                    {featuredArticle.category}
                  </Badge>
                  <h2 className="text-3xl text-white mb-4">
                    {featuredArticle.title}
                  </h2>
                  <p className="text-gray-300 mb-6 text-lg">
                    {featuredArticle.excerpt}
                  </p>
                  <div className="flex items-center gap-6 text-sm text-gray-400 mb-6">
                    <div className="flex items-center gap-2">
                      <User className="size-4" />
                      <span>{featuredArticle.author}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="size-4" />
                      <span>{featuredArticle.date}</span>
                    </div>
                  </div>
                  <motion.div whileHover={{ x: 5 }} className="w-fit">
                    <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 gap-2">
                      Read Full Article <ArrowRight className="size-4" />
                    </Button>
                  </motion.div>
                </div>
              </div>
            </Card>
          </motion.div>
        )}

        {/* Trending Badge */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="flex items-center gap-2 mb-8"
        >
          <TrendingUp className="size-6 text-purple-400" />
          <h2 className="text-2xl text-white">Latest News</h2>
        </motion.div>

        {/* News Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {regularArticles.map((article, index) => (
            <motion.div
              key={article.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 * index }}
              whileHover={{ y: -10 }}
            >
              <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-sm overflow-hidden hover:border-purple-500/50 transition-all h-full flex flex-col">
                <motion.div
                  className="relative h-48 overflow-hidden"
                  whileHover={{ scale: 1.1 }}
                  transition={{ duration: 0.3 }}
                >
                  <ImageWithFallback
                    src={article.image}
                    alt={article.title}
                    className="w-full h-full object-cover"
                  />
                </motion.div>
                <CardHeader>
                  <Badge className="w-fit mb-2 bg-blue-600 hover:bg-blue-700">
                    {article.category}
                  </Badge>
                  <h3 className="text-xl text-white line-clamp-2">
                    {article.title}
                  </h3>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col">
                  <p className="text-gray-300 mb-4 line-clamp-3 flex-1">
                    {article.excerpt}
                  </p>
                  <div className="flex items-center gap-4 text-xs text-gray-400 mb-4">
                    <div className="flex items-center gap-1">
                      <User className="size-3" />
                      <span>{article.author}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="size-3" />
                      <span>{article.date}</span>
                    </div>
                  </div>
                  <motion.div whileHover={{ x: 5 }}>
                    <Button
                      variant="ghost"
                      className="w-full justify-between text-purple-400 hover:text-purple-300 hover:bg-purple-500/10"
                    >
                      Read More
                      <ArrowRight className="size-4" />
                    </Button>
                  </motion.div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Load More Button */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="text-center mt-12"
        >
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button
              size="lg"
              variant="outline"
              className="border-purple-500 text-purple-300 hover:bg-purple-500/10"
            >
              Load More Articles
            </Button>
          </motion.div>
        </motion.div>
      </section>
    </div>
  );
}
