import { motion } from "motion/react";
import { Calendar, Clock, Trophy, MapPin, Users } from "lucide-react";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { useState } from "react";

interface Match {
  id: number;
  teamA: string;
  teamB: string;
  date: string;
  time: string;
  prize: string;
  location: string;
  status: "upcoming" | "live" | "completed";
  scoreA?: number;
  scoreB?: number;
}

const matches: Match[] = [
  {
    id: 1,
    teamA: "Crypto Warriors",
    teamB: "Blockchain Knights",
    date: "June 5, 2026",
    time: "18:00 UTC",
    prize: "50 BTC",
    location: "Virtual Arena",
    status: "upcoming",
  },
  {
    id: 2,
    teamA: "DeFi Dragons",
    teamB: "NFT Ninjas",
    date: "June 4, 2026",
    time: "20:00 UTC",
    prize: "100 ETH",
    location: "Metaverse Stadium",
    status: "live",
    scoreA: 2,
    scoreB: 1,
  },
  {
    id: 3,
    teamA: "Token Titans",
    teamB: "Smart Contract Stars",
    date: "June 3, 2026",
    time: "16:00 UTC",
    prize: "75 BTC",
    location: "Crypto Arena",
    status: "completed",
    scoreA: 3,
    scoreB: 2,
  },
  {
    id: 4,
    teamA: "Altcoin Aces",
    teamB: "Staking Strikers",
    date: "June 6, 2026",
    time: "19:00 UTC",
    prize: "200 ETH",
    location: "Digital Dome",
    status: "upcoming",
  },
  {
    id: 5,
    teamA: "Mining Mavericks",
    teamB: "Ledger Legends",
    date: "June 7, 2026",
    time: "21:00 UTC",
    prize: "150 BTC",
    location: "Chain Colosseum",
    status: "upcoming",
  },
];

export function Fixtures() {
  const [selectedTab, setSelectedTab] = useState("all");

  const filteredMatches =
    selectedTab === "all"
      ? matches
      : matches.filter((match) => match.status === selectedTab);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1542751371-adc38448a05e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3BvcnRzJTIwZ2FtaW5nJTIwdG91cm5hbWVudHxlbnwxfHx8fDE3ODAyNDEzNzJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Esports tournament"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-slate-950/80 via-purple-950/80 to-slate-950" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <Trophy className="size-16 text-purple-400 mx-auto mb-6" />
            <h1 className="text-5xl md:text-6xl text-white mb-4">
              Tournament Fixtures
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Watch the best crypto gaming teams compete for massive prize pools
            </p>
          </motion.div>
        </div>
      </section>

      {/* Fixtures Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Tabs
          value={selectedTab}
          onValueChange={setSelectedTab}
          className="w-full"
        >
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-4 mb-8 bg-slate-900/50 border border-slate-800">
            <TabsTrigger
              value="all"
              className="data-[state=active]:bg-purple-600"
            >
              All
            </TabsTrigger>
            <TabsTrigger
              value="upcoming"
              className="data-[state=active]:bg-purple-600"
            >
              Upcoming
            </TabsTrigger>
            <TabsTrigger
              value="live"
              className="data-[state=active]:bg-purple-600"
            >
              Live
            </TabsTrigger>
            <TabsTrigger
              value="completed"
              className="data-[state=active]:bg-purple-600"
            >
              Completed
            </TabsTrigger>
          </TabsList>

          <TabsContent value={selectedTab} className="mt-0">
            <div className="grid gap-6">
              {filteredMatches.map((match, index) => (
                <motion.div
                  key={match.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.02 }}
                >
                  <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-sm hover:border-purple-500/50 transition-all overflow-hidden">
                    <CardContent className="p-0">
                      <div className="grid md:grid-cols-[1fr,auto,1fr] gap-6 p-6 items-center">
                        {/* Team A */}
                        <motion.div
                          className="text-right md:text-left"
                          whileHover={{ x: 5 }}
                        >
                          <div className="flex items-center justify-end md:justify-start gap-3">
                            <div className="size-16 bg-gradient-to-br from-purple-500 to-blue-500 rounded-xl flex items-center justify-center">
                              <Users className="size-8 text-white" />
                            </div>
                            <div>
                              <h3 className="text-xl text-white mb-1">
                                {match.teamA}
                              </h3>
                              {match.status === "completed" && (
                                <p className="text-3xl text-purple-400">
                                  {match.scoreA}
                                </p>
                              )}
                            </div>
                          </div>
                        </motion.div>

                        {/* Match Info */}
                        <div className="flex flex-col items-center gap-4 min-w-[200px]">
                          <Badge
                            className={`${
                              match.status === "live"
                                ? "bg-red-500 hover:bg-red-600"
                                : match.status === "upcoming"
                                ? "bg-blue-500 hover:bg-blue-600"
                                : "bg-gray-500 hover:bg-gray-600"
                            }`}
                          >
                            {match.status === "live" && (
                              <motion.span
                                className="inline-block size-2 bg-white rounded-full mr-2"
                                animate={{ opacity: [1, 0.3, 1] }}
                                transition={{
                                  duration: 1.5,
                                  repeat: Infinity,
                                }}
                              />
                            )}
                            {match.status.toUpperCase()}
                          </Badge>

                          {match.status !== "completed" ? (
                            <div className="text-center">
                              <div className="flex items-center gap-2 text-gray-300 mb-2">
                                <Calendar className="size-4" />
                                <span>{match.date}</span>
                              </div>
                              <div className="flex items-center gap-2 text-gray-300">
                                <Clock className="size-4" />
                                <span>{match.time}</span>
                              </div>
                            </div>
                          ) : (
                            <div className="text-4xl text-gray-400">VS</div>
                          )}

                          <div className="flex flex-col gap-2 text-sm">
                            <div className="flex items-center gap-2 text-yellow-400">
                              <Trophy className="size-4" />
                              <span>{match.prize}</span>
                            </div>
                            <div className="flex items-center gap-2 text-gray-400">
                              <MapPin className="size-4" />
                              <span>{match.location}</span>
                            </div>
                          </div>
                        </div>

                        {/* Team B */}
                        <motion.div
                          className="text-left md:text-right"
                          whileHover={{ x: -5 }}
                        >
                          <div className="flex items-center gap-3 md:flex-row-reverse">
                            <div className="size-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center">
                              <Users className="size-8 text-white" />
                            </div>
                            <div>
                              <h3 className="text-xl text-white mb-1">
                                {match.teamB}
                              </h3>
                              {match.status === "completed" && (
                                <p className="text-3xl text-purple-400">
                                  {match.scoreB}
                                </p>
                              )}
                            </div>
                          </div>
                        </motion.div>
                      </div>

                      {/* Live Match Progress Bar */}
                      {match.status === "live" && (
                        <motion.div
                          className="h-1 bg-gradient-to-r from-purple-500 via-blue-500 to-purple-500"
                          animate={{
                            backgroundPosition: ["0% 0%", "100% 0%"],
                          }}
                          transition={{
                            duration: 2,
                            repeat: Infinity,
                            ease: "linear",
                          }}
                          style={{
                            backgroundSize: "200% 100%",
                          }}
                        />
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {filteredMatches.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-20"
          >
            <Trophy className="size-16 text-gray-600 mx-auto mb-4" />
            <p className="text-xl text-gray-400">
              No matches found in this category
            </p>
          </motion.div>
        )}
      </section>
    </div>
  );
}
