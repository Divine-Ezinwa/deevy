import { motion } from "motion/react";
import { Video, Play, Eye, Clock, ThumbsUp, Share2, Bookmark } from "lucide-react";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { useState } from "react";

interface VideoItem {
  id: number;
  title: string;
  thumbnail: string;
  duration: string;
  views: string;
  likes: string;
  category: string;
  uploadDate: string;
  description: string;
}

const videos: VideoItem[] = [
  {
    id: 1,
    title: "Bitcoin Trading Strategies for 2026: Complete Guide",
    thumbnail:
      "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcnlwdG8lMjBpbnZlc3RtZW50JTIwY2hhcnR8ZW58MXx8fHwxNzgwMjQxMzcyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    duration: "24:15",
    views: "1.2M",
    likes: "45K",
    category: "Tutorial",
    uploadDate: "2 days ago",
    description:
      "Learn advanced Bitcoin trading strategies from industry experts.",
  },
  {
    id: 2,
    title: "Ethereum 3.0: What You Need to Know",
    thumbnail:
      "https://images.unsplash.com/photo-1644088379091-d574269d422f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxibG9ja2NoYWluJTIwbmV0d29yayUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzgwMjQxMzcyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    duration: "18:42",
    views: "890K",
    likes: "32K",
    category: "News",
    uploadDate: "1 week ago",
    description: "Deep dive into the revolutionary Ethereum 3.0 upgrade.",
  },
  {
    id: 3,
    title: "DeFi Yield Farming: Maximize Your Returns",
    thumbnail:
      "https://images.unsplash.com/photo-1640161704729-cbe966a08476?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcnlwdG9jdXJyZW5jeSUyMGJsb2NrY2hhaW4lMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc4MDI0MTM3MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    duration: "32:08",
    views: "654K",
    likes: "28K",
    category: "DeFi",
    uploadDate: "3 days ago",
    description: "Comprehensive guide to DeFi yield farming strategies.",
  },
  {
    id: 4,
    title: "NFT Market Analysis: Q2 2026 Report",
    thumbnail:
      "https://images.unsplash.com/photo-1623227413711-25ee4388dae3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcnlwdG9jdXJyZW5jeSUyMGdvbGQlMjBjb2lufGVufDF8fHx8MTc4MDI0MTM3Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    duration: "15:30",
    views: "432K",
    likes: "19K",
    category: "Analysis",
    uploadDate: "5 days ago",
    description: "Detailed analysis of current NFT market trends.",
  },
  {
    id: 5,
    title: "Crypto Security: Protecting Your Digital Assets",
    thumbnail:
      "https://images.unsplash.com/photo-1634704784915-aacf363b021f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiaXRjb2luJTIwdHJhZGluZyUyMGRpZ2l0YWx8ZW58MXx8fHwxNzgwMjQxMzcxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    duration: "21:45",
    views: "1.5M",
    likes: "67K",
    category: "Security",
    uploadDate: "1 day ago",
    description: "Essential security practices for crypto investors.",
  },
  {
    id: 6,
    title: "Altcoin Season 2026: Top Picks",
    thumbnail:
      "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcnlwdG8lMjBpbnZlc3RtZW50JTIwY2hhcnR8ZW58MXx8fHwxNzgwMjQxMzcyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    duration: "28:12",
    views: "723K",
    likes: "41K",
    category: "Investment",
    uploadDate: "4 days ago",
    description: "Expert picks for the upcoming altcoin season.",
  },
  {
    id: 7,
    title: "Live Trading Session: Day Trading Crypto",
    thumbnail:
      "https://images.unsplash.com/photo-1644088379091-d574269d422f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxibG9ja2NoYWluJTIwbmV0d29yayUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzgwMjQxMzcyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    duration: "45:22",
    views: "2.1M",
    likes: "89K",
    category: "Live",
    uploadDate: "6 hours ago",
    description: "Watch professional traders in action.",
  },
  {
    id: 8,
    title: "Blockchain Technology Explained",
    thumbnail:
      "https://images.unsplash.com/photo-1640161704729-cbe966a08476?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcnlwdG9jdXJyZW5jeSUyMGJsb2NrY2hhaW4lMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc4MDI0MTM3MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    duration: "19:55",
    views: "567K",
    likes: "24K",
    category: "Education",
    uploadDate: "1 week ago",
    description: "Understanding the fundamentals of blockchain.",
  },
  {
    id: 9,
    title: "Staking Guide: Passive Income with Crypto",
    thumbnail:
      "https://images.unsplash.com/photo-1623227413711-25ee4388dae3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcnlwdG9jdXJyZW5jeSUyMGdvbGQlMjBjb2lufGVufDF8fHx8MTc4MDI0MTM3Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    duration: "26:33",
    views: "934K",
    likes: "52K",
    category: "Tutorial",
    uploadDate: "2 days ago",
    description: "Complete guide to earning passive income through staking.",
  },
];

export function Videos() {
  const [hoveredVideo, setHoveredVideo] = useState<number | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>("All");

  const categories = [
    "All",
    ...Array.from(new Set(videos.map((v) => v.category))),
  ];

  const filteredVideos =
    selectedCategory === "All"
      ? videos
      : videos.filter((v) => v.category === selectedCategory);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <Video className="size-16 text-purple-400 mx-auto mb-6" />
          <h1 className="text-5xl md:text-6xl text-white mb-4">
            Video Library
          </h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Learn from experts with our comprehensive video tutorials and analysis
          </p>
        </motion.div>

        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="flex flex-wrap gap-2 justify-center mb-12"
        >
          {categories.map((category) => (
            <motion.div
              key={category}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button
                variant={selectedCategory === category ? "default" : "outline"}
                onClick={() => setSelectedCategory(category)}
                className={
                  selectedCategory === category
                    ? "bg-purple-600 hover:bg-purple-700"
                    : "border-purple-500/50 text-purple-300 hover:bg-purple-500/10"
                }
              >
                {category}
              </Button>
            </motion.div>
          ))}
        </motion.div>

        {/* Featured Video */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-12"
        >
          <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-sm overflow-hidden hover:border-purple-500/50 transition-all">
            <div className="grid md:grid-cols-2 gap-6">
              <motion.div
                className="relative h-64 md:h-auto overflow-hidden group cursor-pointer"
                whileHover={{ scale: 1.02 }}
                onHoverStart={() => setHoveredVideo(0)}
                onHoverEnd={() => setHoveredVideo(null)}
              >
                <ImageWithFallback
                  src={filteredVideos[0]?.thumbnail}
                  alt={filteredVideos[0]?.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/60 transition-all flex items-center justify-center">
                  <motion.div
                    animate={
                      hoveredVideo === 0
                        ? { scale: 1.2, opacity: 1 }
                        : { scale: 1, opacity: 0.8 }
                    }
                    className="size-20 bg-purple-600 rounded-full flex items-center justify-center"
                  >
                    <Play className="size-10 text-white ml-1" fill="white" />
                  </motion.div>
                </div>
                <Badge className="absolute top-4 left-4 bg-purple-600 hover:bg-purple-700">
                  Featured
                </Badge>
                <div className="absolute bottom-4 right-4 bg-black/80 px-2 py-1 rounded text-white text-sm">
                  {filteredVideos[0]?.duration}
                </div>
              </motion.div>
              <div className="p-6 flex flex-col justify-center">
                <Badge className="w-fit mb-4 bg-blue-600 hover:bg-blue-700">
                  {filteredVideos[0]?.category}
                </Badge>
                <h2 className="text-3xl text-white mb-4">
                  {filteredVideos[0]?.title}
                </h2>
                <p className="text-gray-300 mb-6 text-lg">
                  {filteredVideos[0]?.description}
                </p>
                <div className="flex items-center gap-6 text-sm text-gray-400 mb-6">
                  <div className="flex items-center gap-2">
                    <Eye className="size-4" />
                    <span>{filteredVideos[0]?.views} views</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ThumbsUp className="size-4" />
                    <span>{filteredVideos[0]?.likes}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="size-4" />
                    <span>{filteredVideos[0]?.uploadDate}</span>
                  </div>
                </div>
                <div className="flex gap-3">
                  <motion.div
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="flex-1"
                  >
                    <Button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 gap-2">
                      <Play className="size-4" />
                      Watch Now
                    </Button>
                  </motion.div>
                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <Button
                      variant="outline"
                      size="icon"
                      className="border-purple-500/50 text-purple-300 hover:bg-purple-500/10"
                    >
                      <Bookmark className="size-4" />
                    </Button>
                  </motion.div>
                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <Button
                      variant="outline"
                      size="icon"
                      className="border-purple-500/50 text-purple-300 hover:bg-purple-500/10"
                    >
                      <Share2 className="size-4" />
                    </Button>
                  </motion.div>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Video Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVideos.slice(1).map((video, index) => (
            <motion.div
              key={video.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 * index }}
              whileHover={{ y: -10 }}
              onHoverStart={() => setHoveredVideo(video.id)}
              onHoverEnd={() => setHoveredVideo(null)}
            >
              <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-sm overflow-hidden hover:border-purple-500/50 transition-all h-full flex flex-col">
                <motion.div
                  className="relative h-48 overflow-hidden group cursor-pointer"
                  whileHover={{ scale: 1.1 }}
                  transition={{ duration: 0.3 }}
                >
                  <ImageWithFallback
                    src={video.thumbnail}
                    alt={video.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 group-hover:bg-black/60 transition-all flex items-center justify-center">
                    <motion.div
                      animate={
                        hoveredVideo === video.id
                          ? { scale: 1.2, opacity: 1 }
                          : { scale: 1, opacity: 0.8 }
                      }
                      className="size-16 bg-purple-600 rounded-full flex items-center justify-center"
                    >
                      <Play className="size-8 text-white ml-1" fill="white" />
                    </motion.div>
                  </div>
                  <div className="absolute bottom-2 right-2 bg-black/80 px-2 py-1 rounded text-white text-xs">
                    {video.duration}
                  </div>
                </motion.div>
                <CardContent className="p-4 flex-1 flex flex-col">
                  <Badge className="w-fit mb-2 bg-blue-600 hover:bg-blue-700 text-xs">
                    {video.category}
                  </Badge>
                  <h3 className="text-lg text-white mb-2 line-clamp-2 flex-1">
                    {video.title}
                  </h3>
                  <p className="text-sm text-gray-400 mb-3 line-clamp-2">
                    {video.description}
                  </p>
                  <div className="flex items-center justify-between text-xs text-gray-400 mb-3">
                    <div className="flex items-center gap-1">
                      <Eye className="size-3" />
                      <span>{video.views}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <ThumbsUp className="size-3" />
                      <span>{video.likes}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="size-3" />
                      <span>{video.uploadDate}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <motion.div
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="flex-1"
                    >
                      <Button
                        size="sm"
                        className="w-full bg-purple-600 hover:bg-purple-700 gap-1"
                      >
                        <Play className="size-3" />
                        Watch
                      </Button>
                    </motion.div>
                    <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-purple-500/50 text-purple-300 hover:bg-purple-500/10"
                      >
                        <Bookmark className="size-3" />
                      </Button>
                    </motion.div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Load More Button */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="text-center mt-12"
        >
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button
              size="lg"
              variant="outline"
              className="border-purple-500 text-purple-300 hover:bg-purple-500/10"
            >
              Load More Videos
            </Button>
          </motion.div>
        </motion.div>
      </section>
    </div>
  );
}
