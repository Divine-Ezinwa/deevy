
  # Crypto website with interactions

  This is a code bundle for Crypto website with interactions. The original project is available at https://www.figma.com/design/nKVYcHOkCGNy9d4STVsWGe/Crypto-website-with-interactions.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  