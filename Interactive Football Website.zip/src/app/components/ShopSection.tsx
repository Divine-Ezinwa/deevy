import { motion } from "motion/react";
import { ShoppingCart, Star, Truck } from "lucide-react";

const kits = [
  {
    name: "Home Kit 2026",
    price: "$89.99",
    image: "https://images.unsplash.com/photo-1577212017184-80cc0da11082?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600",
    badge: "Best Seller",
    rating: 4.9,
  },
  {
    name: "Away Kit 2026",
    price: "$89.99",
    image: "https://images.unsplash.com/photo-1616124619460-ff4ed8f4683c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600",
    badge: "New",
    rating: 4.8,
  },
  {
    name: "Third Kit 2026",
    price: "$89.99",
    image: "https://images.unsplash.com/photo-1552066379-e7bfd22155c5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600",
    badge: "Limited",
    rating: 4.7,
  },
];

export function ShopSection() {
  return (
    <section className="py-20 px-4 relative overflow-hidden">
      {/* Top Curve */}
      <div className="absolute top-0 left-0 w-full h-32 bg-purple-950/50 transform -skew-y-2" />

      {/* Animated Background */}
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          rotate: [0, 90, 0],
        }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-br from-yellow-500/5 to-purple-500/5 rounded-full blur-3xl"
      />

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-4">
            Official <span className="text-yellow-400">Shop</span>
          </h2>
          <p className="text-gray-300 text-lg mb-6">Get your official Real Madrid merchandise</p>
          <div className="w-24 h-1 bg-gradient-to-r from-yellow-400 to-yellow-600 mx-auto rounded-full" />
        </motion.div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {[
            { icon: Truck, text: "Free Shipping Over $100" },
            { icon: Star, text: "Official Licensed Products" },
            { icon: ShoppingCart, text: "Secure Checkout" },
          ].map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              className="flex items-center justify-center gap-3 bg-white/5 backdrop-blur-sm rounded-2xl p-4 border border-white/10"
            >
              <feature.icon className="w-6 h-6 text-yellow-400" />
              <span className="text-white">{feature.text}</span>
            </motion.div>
          ))}
        </div>

        {/* Kits Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {kits.map((kit, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.15, duration: 0.5 }}
              whileHover={{ scale: 1.05 }}
              className="group cursor-pointer"
            >
              <div className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-lg rounded-3xl overflow-hidden border border-white/10 hover:border-yellow-400/50 transition-all duration-500">
                {/* Image Container */}
                <div className="relative h-80 bg-gradient-to-br from-purple-900/30 to-slate-900/30 overflow-hidden">
                  <img
                    src={kit.image}
                    alt={kit.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />

                  {/* Badge */}
                  <div className="absolute top-4 right-4">
                    <span className="px-4 py-2 bg-gradient-to-r from-yellow-500 to-yellow-600 text-white rounded-full text-sm shadow-lg">
                      {kit.badge}
                    </span>
                  </div>

                  {/* Quick Add Overlay */}
                  <motion.div
                    initial={{ opacity: 0 }}
                    whileHover={{ opacity: 1 }}
                    className="absolute inset-0 bg-slate-900/80 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  >
                    <button className="px-8 py-4 bg-gradient-to-r from-yellow-500 to-yellow-600 text-white rounded-full hover:shadow-2xl hover:shadow-yellow-500/50 transition-all duration-300 flex items-center gap-2">
                      <ShoppingCart className="w-5 h-5" />
                      Quick Add
                    </button>
                  </motion.div>
                </div>

                {/* Details */}
                <div className="p-6">
                  <div className="flex items-center gap-2 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${
                          i < Math.floor(kit.rating)
                            ? "fill-yellow-400 text-yellow-400"
                            : "text-gray-600"
                        }`}
                      />
                    ))}
                    <span className="text-gray-400 text-sm ml-2">({kit.rating})</span>
                  </div>

                  <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-yellow-400 transition-colors">
                    {kit.name}
                  </h3>

                  <div className="flex items-center justify-between">
                    <span className="text-3xl font-bold text-yellow-400">{kit.price}</span>
                    <button className="p-3 bg-white/10 rounded-full hover:bg-yellow-500 transition-colors duration-300">
                      <ShoppingCart className="w-5 h-5 text-white" />
                    </button>
                  </div>

                  {/* Size Options */}
                  <div className="mt-4 flex gap-2">
                    {["S", "M", "L", "XL", "XXL"].map((size) => (
                      <button
                        key={size}
                        className="flex-1 py-2 bg-white/5 text-white text-sm rounded-lg hover:bg-yellow-500 transition-colors duration-300"
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* View All Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5, duration: 0.5 }}
          className="text-center mt-12"
        >
          <button className="px-12 py-4 bg-gradient-to-r from-yellow-500 to-yellow-600 text-white rounded-full hover:shadow-2xl hover:shadow-yellow-500/50 transition-all duration-300 hover:scale-105">
            View All Products
          </button>
        </motion.div>
      </div>

      {/* Bottom Curve */}
      <div className="absolute bottom-0 left-0 w-full h-32 bg-slate-900 transform skew-y-2" />
    </section>
  );
}
