import { motion } from "motion/react";
import { Clock, TrendingUp } from "lucide-react";

const newsItems = [
  {
    title: "Real Madrid Wins Champions League Final",
    excerpt: "Los Blancos claim their 16th European crown with a stunning performance at Wembley Stadium.",
    image: "https://images.unsplash.com/photo-1560272564-c83b66b1ad12?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
    category: "Match Report",
    time: "2 hours ago",
    featured: true,
  },
  {
    title: "New Signing Breaks Transfer Record",
    excerpt: "Real Madrid announces the acquisition of world-class midfielder in record-breaking deal.",
    image: "https://images.unsplash.com/photo-1508087625439-de3978963553?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
    category: "Transfer News",
    time: "5 hours ago",
    featured: false,
  },
  {
    title: "Youth Academy Produces Another Star",
    excerpt: "17-year-old sensation makes first-team debut and scores spectacular goal.",
    image: "https://images.unsplash.com/photo-1504305754058-2f08ccd89a0a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
    category: "Youth Development",
    time: "1 day ago",
    featured: false,
  },
  {
    title: "Stadium Renovation Unveils New Features",
    excerpt: "Santiago Bernabéu's latest upgrades set new standard for modern football stadiums worldwide.",
    image: "https://images.unsplash.com/photo-1663061911520-e97fa3428f2b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
    category: "Club News",
    time: "2 days ago",
    featured: false,
  },
];

export function News() {
  return (
    <section className="py-20 px-4 bg-gradient-to-b from-slate-900 to-purple-950/50">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-4">
            Latest <span className="text-yellow-400">News</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-yellow-400 to-yellow-600 mx-auto rounded-full" />
        </motion.div>

        {/* Featured News */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-8 relative rounded-3xl overflow-hidden group cursor-pointer"
        >
          <div className="relative h-96 md:h-[500px]">
            <img
              src={newsItems[0].image}
              alt={newsItems[0].title}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/60 to-transparent" />

            <div className="absolute bottom-0 left-0 right-0 p-8 md:p-12">
              <div className="flex items-center gap-4 mb-4">
                <span className="px-4 py-1 bg-yellow-500 text-slate-900 rounded-full text-sm">
                  {newsItems[0].category}
                </span>
                <div className="flex items-center gap-2 text-gray-300">
                  <Clock className="w-4 h-4" />
                  <span className="text-sm">{newsItems[0].time}</span>
                </div>
              </div>
              <h3 className="text-4xl md:text-5xl font-bold text-white mb-4">
                {newsItems[0].title}
              </h3>
              <p className="text-gray-300 text-lg max-w-3xl mb-6">
                {newsItems[0].excerpt}
              </p>
              <button className="px-6 py-3 bg-white/10 backdrop-blur-sm border border-white/20 text-white rounded-full hover:bg-yellow-500 hover:border-yellow-500 transition-all duration-300">
                Read More
              </button>
            </div>
          </div>
        </motion.div>

        {/* News Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {newsItems.slice(1).map((news, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              whileHover={{ y: -10 }}
              className="bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-lg rounded-3xl overflow-hidden border border-white/10 hover:border-yellow-400/50 transition-all duration-300 cursor-pointer group"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={news.image}
                  alt={news.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent" />
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-purple-600/80 backdrop-blur-sm text-white rounded-full text-xs">
                    {news.category}
                  </span>
                </div>
              </div>

              <div className="p-6">
                <div className="flex items-center gap-2 text-gray-400 mb-3">
                  <Clock className="w-3 h-3" />
                  <span className="text-xs">{news.time}</span>
                </div>
                <h4 className="text-xl font-bold text-white mb-3 group-hover:text-yellow-400 transition-colors">
                  {news.title}
                </h4>
                <p className="text-gray-300 text-sm mb-4 line-clamp-2">
                  {news.excerpt}
                </p>
                <div className="flex items-center gap-2 text-yellow-400 group-hover:gap-4 transition-all">
                  <span className="text-sm">Read More</span>
                  <TrendingUp className="w-4 h-4" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
