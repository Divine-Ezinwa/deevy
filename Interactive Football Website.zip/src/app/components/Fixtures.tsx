import { motion } from "motion/react";
import { Calendar, MapPin, Trophy, Clock, Ticket } from "lucide-react";

const fixtures = [
  {
    date: "JUN 05",
    fullDate: "Thursday, June 5, 2026",
    time: "21:00",
    competition: "La Liga",
    opponent: "Barcelona",
    opponentShort: "FCB",
    venue: "Santiago Bernabéu",
    location: "Madrid",
    isHome: true,
    color: "from-red-600 to-red-800",
  },
  {
    date: "JUN 12",
    fullDate: "Thursday, June 12, 2026",
    time: "18:45",
    competition: "Champions League",
    opponent: "Bayern Munich",
    opponentShort: "FCB",
    venue: "Allianz Arena",
    location: "Munich",
    isHome: false,
    color: "from-blue-600 to-blue-800",
  },
  {
    date: "JUN 19",
    fullDate: "Thursday, June 19, 2026",
    time: "20:00",
    competition: "La Liga",
    opponent: "Atlético Madrid",
    opponentShort: "ATM",
    venue: "Santiago Bernabéu",
    location: "Madrid",
    isHome: true,
    color: "from-red-600 to-red-800",
  },
  {
    date: "JUN 26",
    fullDate: "Thursday, June 26, 2026",
    time: "19:30",
    competition: "Copa del Rey",
    opponent: "Sevilla",
    opponentShort: "SFC",
    venue: "Ramón Sánchez Pizjuán",
    location: "Sevilla",
    isHome: false,
    color: "from-orange-600 to-orange-800",
  },
];

export function Fixtures() {
  return (
    <section className="py-20 px-4 relative overflow-hidden">
      {/* Background Curve */}
      <div className="absolute top-0 left-0 w-full h-32 bg-slate-900 transform -skew-y-2" />

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-4">
            Upcoming <span className="text-yellow-400">Fixtures</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-yellow-400 to-yellow-600 mx-auto rounded-full" />
        </motion.div>

        <div className="space-y-6">
          {fixtures.map((fixture, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              whileHover={{ scale: 1.02 }}
              className="relative group"
            >
              <div className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-xl rounded-3xl overflow-hidden border border-white/20 hover:border-yellow-400/60 transition-all duration-500 shadow-2xl hover:shadow-yellow-500/20">
                <div className="flex flex-col md:flex-row">
                  {/* Date Section */}
                  <div className={`bg-gradient-to-br ${fixture.color} p-6 md:p-8 flex flex-col items-center justify-center min-w-[140px] relative overflow-hidden`}>
                    <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent" />
                    <div className="relative z-10 text-center">
                      <div className="text-3xl md:text-4xl font-bold text-white mb-1">
                        {fixture.date.split(' ')[1]}
                      </div>
                      <div className="text-sm text-white/90 uppercase tracking-widest">
                        {fixture.date.split(' ')[0]}
                      </div>
                      <div className="mt-3 flex items-center gap-1 text-white/80">
                        <Clock className="w-3 h-3" />
                        <span className="text-xs">{fixture.time}</span>
                      </div>
                    </div>
                    <div className="absolute -right-8 -bottom-8 w-24 h-24 bg-white/10 rounded-full blur-2xl" />
                  </div>

                  {/* Main Content */}
                  <div className="flex-1 p-6 md:p-8">
                    {/* Competition Header */}
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center gap-2">
                        <Trophy className="w-5 h-5 text-yellow-400" />
                        <span className="text-yellow-400 font-bold">{fixture.competition}</span>
                      </div>
                      <span
                        className={`px-4 py-1.5 rounded-full text-xs font-bold ${
                          fixture.isHome
                            ? "bg-gradient-to-r from-green-500 to-emerald-600 text-white"
                            : "bg-gradient-to-r from-blue-500 to-cyan-600 text-white"
                        } shadow-lg`}
                      >
                        {fixture.isHome ? "HOME MATCH" : "AWAY MATCH"}
                      </span>
                    </div>

                    {/* Teams */}
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center gap-4 flex-1">
                        <div className="relative">
                          <div className="w-16 h-16 md:w-20 md:h-20 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-2xl flex items-center justify-center shadow-2xl shadow-yellow-500/40 group-hover:scale-110 transition-transform duration-500">
                            <span className="text-xl md:text-2xl font-bold text-white">RM</span>
                          </div>
                          <div className="absolute -top-1 -right-1 w-6 h-6 bg-green-500 rounded-full border-2 border-slate-900 flex items-center justify-center">
                            <span className="text-white text-xs">●</span>
                          </div>
                        </div>
                        <div>
                          <div className="text-white font-bold text-xl md:text-2xl">Real Madrid</div>
                          <div className="text-gray-400 text-sm">Los Blancos</div>
                        </div>
                      </div>

                      <div className="px-4 md:px-8">
                        <div className="text-4xl md:text-5xl font-bold text-transparent bg-gradient-to-br from-yellow-400 to-yellow-600 bg-clip-text">
                          VS
                        </div>
                      </div>

                      <div className="flex items-center gap-4 flex-1 justify-end">
                        <div className="text-right">
                          <div className="text-white font-bold text-xl md:text-2xl">{fixture.opponent}</div>
                          <div className="text-gray-400 text-sm">{fixture.opponentShort}</div>
                        </div>
                        <div className="w-16 h-16 md:w-20 md:h-20 bg-gradient-to-br from-slate-700 to-slate-900 rounded-2xl flex items-center justify-center shadow-2xl border-2 border-white/10 group-hover:scale-110 transition-transform duration-500">
                          <span className="text-xl md:text-2xl font-bold text-white">{fixture.opponentShort}</span>
                        </div>
                      </div>
                    </div>

                    {/* Location & Action */}
                    <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pt-4 border-t border-white/10">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-gray-300">
                          <Calendar className="w-4 h-4 text-yellow-400" />
                          <span className="text-sm">{fixture.fullDate}</span>
                        </div>
                        <div className="flex items-center gap-2 text-gray-300">
                          <MapPin className="w-4 h-4 text-yellow-400" />
                          <span className="text-sm">{fixture.venue}, {fixture.location}</span>
                        </div>
                      </div>

                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-yellow-500 to-yellow-600 text-white rounded-full shadow-lg shadow-yellow-500/30 hover:shadow-yellow-500/50 transition-all duration-300"
                      >
                        <Ticket className="w-4 h-4" />
                        <span>Get Tickets</span>
                      </motion.button>
                    </div>
                  </div>
                </div>

                {/* Animated accent line */}
                <motion.div
                  className="h-1 bg-gradient-to-r from-yellow-400 via-yellow-500 to-yellow-600"
                  initial={{ scaleX: 0 }}
                  whileInView={{ scaleX: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 + 0.3, duration: 0.8 }}
                />
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Bottom Curve */}
      <div className="absolute bottom-0 left-0 w-full h-32 bg-slate-900 transform skew-y-2" />
    </section>
  );
}
