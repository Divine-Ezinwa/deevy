import { Navigation } from "./components/Navigation";
import { Hero } from "./components/Hero";
import { Fixtures } from "./components/Fixtures";
import { News } from "./components/News";
import { ShopSection } from "./components/ShopSection";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-950 to-slate-900">
      <Navigation />
      <div id="home">
        <Hero />
      </div>
      <div id="fixtures">
        <Fixtures />
      </div>
      <div id="news">
        <News />
      </div>
      <div id="shop">
        <ShopSection />
      </div>
      <Footer />
    </div>
  );
}
